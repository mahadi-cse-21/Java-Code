package mahadi;

public class Y extends X {

}
