package mahadi;

public class X {

}
