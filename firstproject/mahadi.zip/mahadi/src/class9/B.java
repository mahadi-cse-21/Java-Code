package class9;

public class B extends A{
	void method2(){
		System.out.println("i am B : >");
		
	}

}
