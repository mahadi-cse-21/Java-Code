package class9;

public interface Abc {

	public abstract void m();
}
