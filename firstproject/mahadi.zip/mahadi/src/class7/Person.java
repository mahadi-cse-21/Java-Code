package class7;

public class Person {

}
