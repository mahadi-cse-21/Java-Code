package class7;

 public class Dept {
	 void bsmru()
	{
		System.out.println("Hi");
	}

}
