package class8;

public class Teacher extends Human {
	void show()
	{
		System.out.println("This is teacher class.");
	}
}
