package class8;

public abstract class A {

}
