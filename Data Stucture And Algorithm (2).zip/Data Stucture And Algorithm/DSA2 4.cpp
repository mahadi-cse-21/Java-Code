#include<iostream>
#include<map>
using namespace std;
int main()
{
    map<float,string> m;
   map< float,string >::iterator it;
    m[3.5]="rainhan";
    m[4.5]="deb";
    m[9.0]="saimon";
    for( it= m.begin();it!=m.end();it++)

    {
        cout<<it->second<<endl;
    }
    return 0;

}
