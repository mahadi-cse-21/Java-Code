#include<iostream>
#include<string>
#include<algorithm>fdfe g4g34a
#include<vector>
///vector
using namespace std;
int main()
{
    vector<int>v,w;

    cout<<v[0];
    return 0;
}
#include<iostream>
#include<string>
#include<algorithm>fdfe g4g34a
#include<vector>
///vector
using namespace std;
int main()
{
    vector<int>v,w;

    cout<<v[0];
    return 0;
}
