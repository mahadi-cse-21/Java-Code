#include <iostream>
using namespace std;

struct Node
{
    int key;
    Node* next;
};

struct Stack
{

    Node* top = nullptr;

    void push(int x)
    {
        Node*temp=(Node*)malloc(sizeof(Node));
        temp->key=x;
        temp->next=top;
        top=temp;
        cout<<x<<"has been pushed onto the stack"<<endl;
    }

    int pop()
    {
        if(top==NULL)
        {
            cout<<"Stack underflow"<<endl;
            return -1;
        }
        Node*temp=top;
        top=top->next;
        return temp->key;
        free(temp);
    }

    void print()
    {
        if(top==NULL)
        {
            cout<<"Stack is empty."<<endl;
            return ;
        }
        Node*temp=top;
        cout<<"STACK :";
        while(temp!=NULL)
        {
            cout<<temp->key<<" ";
            temp=temp->next;
        }
        cout<<endl;
    }

    int topValue()
    {
        if(top==NULL)
        {
            cout<<"Stack is empty"<<endl;
            return -1;
        }
        return top->key;
    }


    bool isEmpty()
    {
        return (top == nullptr);
    }

    int size()
    {
        if(top==NULL) return 0;
        top=top->next;
        return 1+ size();

    }
};

int main() {
    int choice, value;
    Stack st;
    while (true) {
        cout << "\n1.Push\n2.Pop\n3.Print\n4.Top\n5.Empty\n6.Size\n7.Exit" << endl;
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to push: ";
                cin >> value;
                st.push(value);
                break;
            case 2:
                cout << "Popped value: " << st.pop() << endl;
                break;
            case 3:
                st.print();
                break;
            case 4:
                cout << "Top value: " << st.topValue() << endl;
                break;
            case 5:
                cout << (st.isEmpty() ? "Stack is empty." : "Stack is not empty.") << endl;
                break;
            case 6:
                cout << "Size of the stack: " << st.size() << endl;
                break;
            case 7:
                cout << "Exiting program." << endl;
                exit(0);
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}
