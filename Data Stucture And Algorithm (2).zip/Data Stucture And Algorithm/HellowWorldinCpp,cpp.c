#incldue<bits/stdc++.h>
using namespace std;


namespace firstname
{
    void method()
    {
        cout<<"I'm from first space"<< endl;
    }
}
namespace secondname
{
    void method()
    {
        cout<<"I'm from second space"<<endl;
    }
}
using namespace secondname;
int main(){
    method();
}
