#include<stdio.h>
int main(){

int n,count=0;
while(n>0){
    n=n/5;
    count=count+n;


}








return 0;
}
