void sumoftwonum(int a,int b){cout<< (a+b);}
