#include<bits/stdc++.h>
using namespace std;


struct Stack
{
    struct node
    {
        int key;
        node *next;
    };
    node* top=NULL;
    void push(int x)
    {
        node *temp=(node*)malloc(sizeof(node));
        temp->key=x;
        temp->next=top;
        top=temp;

    }
    int pop()
    {
        if(top==NULL)
        {
            return -1;
        }
        node * temp = top;
        int k = top->key;
        top=top->next;
        delete temp;
        return k;
    }
    int topValue()
    {
        if(top==NULL) return -1;
        return top->key;

    }
    int size()
    {
        int count=0;
        node *temp=top;
        while(temp!=NULL)
        {
            temp=temp->next;
            count++;
        }
        return count;
    }
    bool isEmpty()
    {
        if(top!=NULL) return false;
        return true;
    }
    void show()
    {
        node * temp=top;
        while(temp!=NULL)
        {
          printf("%c ",temp->key);
            temp=temp->next;
        }
        cout<<endl;
    }
};
int main()
{

    Stack s1 ;
    char m='(';
    char n=')';
    char o='{';
    char p='}';
    char q='[';
    char r=']';
    string a;
    cin>>a;
    int len = a.size();

    int tmp=0;
    for(int i=0; i<len; i++)
    {
        if(a[i]=='('|| a[i]=='{'|| a[i]=='[')
        {
            s1.push(a[i]);
        }
        else if ((a[i]==m&&s1.topValue()==n) ||
                 (a[i]==o&&s1.topValue()==p)||
                 (a[i]==q&&s1.topValue()==r))
        {
            int l =s1.pop();
        }
        else if((a[i]!=m||a[i]!=n)||
                 (a[i]!=o||a[i]!=p)||
                 (a[i]!=q||a[i]!=r))
        {

            continue;

        }
        else
        {
            tmp=1;
              break;
        }


    }
    if(tmp==0 && s1.size()==0) cout<<"Balanced"<<endl;
    else cout<<"Unbalanced"<<endl;

    return 0;
}
