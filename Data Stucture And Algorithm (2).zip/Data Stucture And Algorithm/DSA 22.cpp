#include<iostream>
using namespace std;
class A
{
   public:

    int m;

    int n;
    int add()
    {
        return m+n;
    }
     A(int a ,int b)
     {
         m=a;
         n=b;
     }
};
int main()
{
    A p(3,3),q(3,6);

  cout<<p.add()<<endl;
    return 0;

}



