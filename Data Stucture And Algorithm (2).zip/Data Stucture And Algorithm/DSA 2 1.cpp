#include<iostream>
using namespace std;
int main()
{
    int a,b;
    cin>>a>>b;
    cout<<"Avg of "<<a<<" and "<<b<<" is "<<(a+b)/2<<endl;
    return 0;

}


