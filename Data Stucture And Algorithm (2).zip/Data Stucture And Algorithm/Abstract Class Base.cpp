#include<bits/stdc++.h>
using namespace std;


class Bkash
{
    private:
    int balance;
    Bkash(int amount): balance(amount){} ///this is constructor;

    /// For cash deposit


};

int main()
{
    Bkash person(1000); /// Initializing the value using constructor
    //person.deposit(10);

}
