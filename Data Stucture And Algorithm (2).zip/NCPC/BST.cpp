#include<bits/stdc++.h>
using namespace std;
struct node
{
    int key;
    node* l,*r,*p;
    node(int x)
    {
        key=x;
        l=r=p=NULL;
    }

};
struct bst
{
    node *root;
    bst()
    {
        root=NULL;
    }
    void insert(int x)
    {

        node *temp= new node(x);
        if(root==NULL)
        {
            root=temp;
            return;
        }
        node *fast = root;
        node * slow=NULL;
        while(fast!=NULL)
        {
            slow = fast;
            if(x<fast->key)
            {
                fast=fast->l;
            }
            else
            {
                fast=fast->r;
            }
        }
        if(x<slow->key)  slow->l=temp;
        else slow->r=temp;
        temp->p=slow;
    }

    void inorder(node* temp)
    {
        if(temp==NULL)
        {
            return;
        }
        inorder(temp->l);
        cout<<temp->key<<" ";
        inorder(temp->r);
    }
    int maximum(node* temp)
    {
    if(temp->r==NULL) return temp->key;
     return maximum(temp->r);
    }
};
int main()
{
    bst s1;
    int choice;
    while(1)
    {
        cout<<" Insert choice : ";
        cin>>choice;
        if(choice==1)
        {
            cout<<"Insert a value :";
            int a;
            cin>>a;
            s1.insert(a);
        }
        else if(choice == 2)
        {
            cout<<" sorted : ";
            s1.inorder(s1.root);
            cout<<endl;
        }
        else
            break;

    }
cout<<"Maximum :"<<s1.maximum(s1.root);
}
/*
1
44
1
17
1
88
1
32
1
65
1
97
1
12
*/
