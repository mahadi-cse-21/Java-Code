#include<bits/stdc++.h>
using namespace std;
struct node{
int key;
node *R,*L;
};
struct DLL;
{
        node *head=NULL;
        node*tail=NULL;
        void insertFirst( int x)
        {


        }
};
int main()
{

    return 0;
}
