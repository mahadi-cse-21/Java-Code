#include<stdio.h>
int main()
{
    int n,i;
    printf("Enter the number: ");
    scanf("%d",&n);
    if(n%n!=0){
        for(i=1;i<=n;i++){
                printf("%d",i);
        }
    }


    return 0;
}
