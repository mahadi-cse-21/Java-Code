#include<stdio.h>
int main()
{
    int a,b,c;
    printf("Enter the three sides of a tringle: ");
    scanf("%d%d%d",&a,&b,&c);

    if(a+b>c)
    {
        printf("Valid triangle");
    }
    else
    {
        printf("Not a valid triangle");
    }
    printf("\n");
    if(a*a==b*b+c*c)
    {
        printf("Right-angled trigle");
    }
    else
    {
        printf("Not a right-angled triangle");
    }

    return 0;
}
