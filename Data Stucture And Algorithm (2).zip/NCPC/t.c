#include<stdio.h>
int main()
{
    printf("u");
    return 0;
}
