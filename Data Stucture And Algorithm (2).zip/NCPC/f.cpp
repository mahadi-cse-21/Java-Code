#include<bits/stdc++.h>
using namespace std;
int main(){

    int t;
    cin >> t;
    for(int k = 1; k <= t; k++){
        int n;
        cin >> n;
        int a[n];
        for(int i=0; i < n; i++) cin >> a[i];
        sort(a,a+n);

        int c = 0;
        int test = a[0];

        for(int i= 0; i < n -1; i++){
            if(a[i] != a[i+1]){
                c++;
                test = a[i+1];
            }

        }

        cout << "Case " << k << ": "<< c << endl;

    }

    return 0;
}
