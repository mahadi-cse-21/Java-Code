#include<stdio.h>
int main()
{
    int i,  j,n, temp,ara[1000],loc,num, left, right, mid;
    printf("enter the element number: ");
    scanf("%d", &n);
    printf("enter the element: ");
    for(i=0;i<n;i++){
        scanf("%d", &ara[i]);

    }
    printf("\n");
     for(i=0;i<n;i++){
        printf("%d ", ara[i]);

    }
    printf("\n");

    for(i=0;i<n-1;i++){
         for(j=i+1;j<n;j++){
        if(ara[i]<=ara[j]){
            temp=ara[i];
            ara[i]=ara[j];
            ara[j]=temp;
        }

    }
    }
    for(i=0;i<n;i++){
        printf("%d ", ara[i]);

    }
    printf("enter the location you want to search: ");
    scanf("%d",&num);
    left=ara[0];
    right=ara[n-1];
    for(i=0;i<n;i++){
    mid= (left+right)/2;
    if(ara[mid]==num){
        printf("the location is %d", ara[mid]);
        return 0;
    }
    else if(num<ara[mid]){
        right=mid-1;
    }
    else{
        right=mid-1;
        left=mid+1;
    }}
    return 0;
}
