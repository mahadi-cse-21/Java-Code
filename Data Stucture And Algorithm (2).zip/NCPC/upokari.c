#include<stdio.h>
int main()
{

    int i,number,j,product;
    scanf("%d",&number);
    for(i=1;i<=number;i++)
    {
        for(j=1;j<=10;j++)
        {

            product=i*j;
            printf("%d x %d = %d\n",i,j,product);
        }
       //  printf("%d x %d=%d\n",i,j,product);

    }

    return 0;
}

