#include<bits/stdc++.h>
using namespace std;


void push(stacarray&stack,int x)

{
    if(stack.top>=)
}

int main()
{

    return 0;
}
