#include<bits/stdc++.h>
using namespace std;
int main()
{
    stack<char>st;
    string s;
    cin>>s;
    int tmp=0;
    for(int i=0; i<s.size(); i++)
    {
        char c = s[i];
        if(c=='('  || c=='{'||c=='[')
        {
            st.push(c);
        }
        else if(c==')'  || c =='}'|| c==']')
        {
            if(st.size()==0)
            {
                tmp=1;
                break;
            }
            if(c ==')' &&  st.top()=='(' )    st.pop();
          else  if(c=='}'  &&  st.top()=='{')    st.pop();
          else   if(c==']'  &&  st.top()=='[')    st.pop();
            else
            {
                tmp=1;
                break;
            }
        }
    }
    if(tmp==1 || st.size()>0)
    {
        cout<<"Unbalanced"<<endl;
    }
    else
    {
        cout<<"Balanced"<<endl;
    }

return 0;
}
