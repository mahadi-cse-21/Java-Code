#include<iostream>
#include<algorithm>
#include<map>

using namespace std;
int main()
{
    int n;

    scanf("%d ",&n);
    map<string,int> mp;
   for(int i=0;i<n;i++)
    {
        string s;
      getline(cin,s);
      mp[s]++;
    }
    //sort(mp.begin(),mp.end());
    for(auto it: mp)
    {
        cout<<it.first<<"("<<it.second<<")"<<endl;
    }
    return 0;
}
