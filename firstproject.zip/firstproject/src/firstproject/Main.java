package firstproject;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*	Student obj = new Student();	
	Student obj1 = new Student();	
	Student obj2 = new Student();
	obj1.set("Saimo", 104);
	obj.set("Saim", 104);
	obj2.set("aiman", 104);	
	obj1.showInfo();
	obj2.showInfo();
	obj.showInfo();
	*/
		Student s1 = new Student("fahim", 103);
		
		s1.showInfo();
		Student s2 = new Student();
		s2.showInfo();		
	}

} 
