package firstproject;

public class Area {
int length;
int width;
int  area()
		{
			return length * width;
		}
int result = area();
void show()
{
	System.out.println("hi ");
}
}
