package mahadi;

public class mahdi {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//Student obj = new Student("AAb",1);
//		obj.show();	
//		Student obj1 = new Student("BBa",2);
//		obj1.show();
//		Student obj2 = new Student("C",3);
//		obj2.show();
//		Student obj3 = new Student("D",4);
//		obj3.show();     
//      System.out.println("Dept: "+Student.dept);
//      obj.display();
// Student.display1();
//      Student obj4 = new Student();
//      obj4.show1();
//      Student obj5 = new Student();
//      obj5.show1();
//      Student obj6 = new Student();
//      obj6.show1();
		
//		/////*inheritance*/////
/*Student1 obj = new Student1();
obj.setName("Mahadi Hassan");
 obj.setage(5);
 obj.setRoll(8);
/* System.out.println(obj.getName());
 System.out.println(obj.getAge());
 System.out.println(obj.getRoll());*/
		//method overriding
 //obj.show();
		//////encaptulation in inherritance///////
/*Stu obj = new Stu("Mahadi",20,20);
obj.show();*/

		
 
}
}

