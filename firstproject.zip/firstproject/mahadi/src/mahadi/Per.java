package mahadi;

public class Per {
	String name;
	int age;
	Per(String n,int a)
	{
		name = n;
		age=a;
	}
int a=10;
void show()
{
	System.out.println("Name : "+name);
	System.out.println("Age : "+age);
	
	
}
}
