package class10;

public class B {


}
