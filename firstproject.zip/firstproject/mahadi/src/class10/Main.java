package class10;

import newpackage.A;


public class Main {

	public static void main(String[] args) {
		A  mob = new A();
		mob.method();
		
	}

}
