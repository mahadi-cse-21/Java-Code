package class11;

public class Main {

	public static void main(String[] args) {
   int x=50;
   int y=0;
   int rest=x/y;
   System.out.println(rest);
	}

}
