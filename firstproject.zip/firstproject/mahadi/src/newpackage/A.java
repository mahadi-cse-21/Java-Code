package newpackage;
import class10.Main;
public class A extends Main {
	 public void method()
	{
		System.out.println("this is package new");
	}

}
