package class8;

public class Student extends Human{
	void show()
	{
		System.out.println("This is student class.");
	}

}
