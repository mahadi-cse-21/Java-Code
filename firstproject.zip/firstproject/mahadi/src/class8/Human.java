package class8;

public class Human {
	void show()
	{
		System.out.println("This is human class.");
		
	}

}
