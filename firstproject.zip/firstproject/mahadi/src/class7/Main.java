package class7;

import java.util.Scanner;

///import java.util.*;
public class Main {


	public static void main(String[] args) {

		
		@SuppressWarnings("unused")
		Scanner object= new  Scanner(System.in);
		//java.util.Scanner ob = new java.util.Scanner(System.in);

		

	}

}
