package class9;

public class Bike implements Abc,Bkc {
	public void m() 
	{
		System.out.println("This is a new message. ");
	}

}
