package class9;

public abstract  class A {
	void method1()
	{
		System.out.println("who are you ?");
	}
	abstract void method2();
	
}
