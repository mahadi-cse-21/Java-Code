package class9;

public class C extends  A {
	void method2()
	{
		System.out.println("i am C : >");
	}

}
