package class9;

public interface Bkc {
	
public abstract	void m();

}
